package com.harrison.weighttracker;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

/**
 * Displays all recorded weights and provides navigation to:
 * - AddWeightActivity
 * - SetGoalActivity
 */
public class WeightHistoryActivity extends AppCompatActivity {

    private RecyclerView rvDataGrid;
    private Button btnAddData;
    private Button btnSetGoal;

    private DataGridAdapter adapter;
    private final List<DataItem> dataList = new ArrayList<>();

    private UserDataBase dataBase;

    private final ActivityResultLauncher<Intent> addWeightLauncher =
            registerForActivityResult(
                    new ActivityResultContracts.StartActivityForResult(),
                    result -> {
                        if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                            String date = result.getData().getStringExtra("date");
                            String weight = result.getData().getStringExtra("weight");

                            if (date != null && weight != null) {
                                // Save to database
                                dataBase.addWeightEntry(date, weight);

                                // Update RecyclerView
                                DataItem newItem = new DataItem(date, weight);
                                dataList.add(newItem);
                                adapter.notifyItemInserted(dataList.size() - 1);
                            }
                        }
                    }
            );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.weight_history_activity);

        dataBase = new UserDataBase(this);

        initViews();
        setupRecyclerView();
        setupListeners();
        loadDataFromDatabase();
    }

    private void initViews() {
        rvDataGrid = findViewById(R.id.rvDataGrid);
        btnAddData = findViewById(R.id.btnAddData);
        btnSetGoal = findViewById(R.id.btnSetGoal);
    }

    private void setupListeners() {
        btnAddData.setOnClickListener(v -> openAddWeightScreen());
        btnSetGoal.setOnClickListener(v -> startActivity(new Intent(this, SetGoalActivity.class)));
    }

    private void setupRecyclerView() {
        adapter = new DataGridAdapter(dataList, this::onDeleteDataClick);
        rvDataGrid.setLayoutManager(new LinearLayoutManager(this));
        rvDataGrid.setAdapter(adapter);
    }

    /** Load all weights from database */
    private void loadDataFromDatabase() {
        dataList.clear();
        List<UserDataBase.DataItem> entries = dataBase.getAllWeightEntries();
        for (UserDataBase.DataItem entry : entries) {
            dataList.add(new DataItem(entry.date, entry.value));
        }
        adapter.notifyDataSetChanged();
    }

    private void openAddWeightScreen() {
        addWeightLauncher.launch(new Intent(this, AddWeightActivity.class));
    }

    /** Delete a weight entry */
    private void onDeleteDataClick(DataItem item) {
        dataBase.deleteWeightEntry(item.date);
        int index = dataList.indexOf(item);
        if (index != -1) {
            dataList.remove(index);
            adapter.notifyItemRemoved(index);
        }
    }

    /** Local DataItem class for RecyclerView */
    public static class DataItem {
        public String date;
        public String value;

        public DataItem(String date, String value) {
            this.date = date;
            this.value = value;
        }
    }
}
