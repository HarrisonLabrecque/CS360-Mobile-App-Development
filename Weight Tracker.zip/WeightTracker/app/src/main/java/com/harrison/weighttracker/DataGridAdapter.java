package com.harrison.weighttracker;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class DataGridAdapter extends RecyclerView.Adapter<DataGridAdapter.ViewHolder> {

    private final List<WeightHistoryActivity.DataItem> dataList;
    private final OnDeleteClickListener deleteListener;

    public interface OnDeleteClickListener {
        void onDeleteClick(WeightHistoryActivity.DataItem item);
    }

    public DataGridAdapter(List<WeightHistoryActivity.DataItem> dataList, OnDeleteClickListener listener) {
        this.dataList = dataList;
        this.deleteListener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.data_item_row, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        WeightHistoryActivity.DataItem item = dataList.get(position);
        holder.tvDate.setText(item.date);
        holder.tvValue.setText(item.value);
        holder.btnDelete.setOnClickListener(v -> deleteListener.onDeleteClick(item));
    }

    @Override
    public int getItemCount() {
        return dataList.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvDate, tvValue;
        Button btnDelete;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvDate = itemView.findViewById(R.id.tvDate);
            tvValue = itemView.findViewById(R.id.tvValue);
            btnDelete = itemView.findViewById(R.id.btnDelete);
        }
    }
}
