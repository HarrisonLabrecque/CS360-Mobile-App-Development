package com.harrison.weighttracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

/**
 * Database helper for Users, Weights, and Goal tracking.
 */
public class UserDataBase extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "users.db";
    private static final int VERSION = 2;

    public UserDataBase(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    // Users table
    private static final class UserTable {
        private static final String TABLE = "users";
        private static final String COL_ID = "id";
        private static final String COL_USERNAME = "username";
        private static final String COL_PASSWORD = "password_hash";
    }

    // Weights table
    private static final class WeightTable {
        private static final String TABLE = "weights";
        private static final String COL_ID = "id";
        private static final String COL_DATE = "date";
        private static final String COL_WEIGHT = "weight";
    }

    // Goal table
    private static final class GoalTable {
        private static final String TABLE = "goal";
        private static final String COL_ID = "id";
        private static final String COL_GOAL_WEIGHT = "goal_weight";
        private static final String COL_SMS_ENABLED = "sms_enabled";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Users table
        String sqlUsers = "CREATE TABLE " + UserTable.TABLE + " (" +
                UserTable.COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                UserTable.COL_USERNAME + " TEXT UNIQUE NOT NULL, " +
                UserTable.COL_PASSWORD + " TEXT NOT NULL)";
        db.execSQL(sqlUsers);

        // Weights table
        String sqlWeights = "CREATE TABLE " + WeightTable.TABLE + " (" +
                WeightTable.COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                WeightTable.COL_DATE + " TEXT NOT NULL, " +
                WeightTable.COL_WEIGHT + " TEXT NOT NULL)";
        db.execSQL(sqlWeights);

        // Goal table
        String sqlGoal = "CREATE TABLE " + GoalTable.TABLE + " (" +
                GoalTable.COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                GoalTable.COL_GOAL_WEIGHT + " TEXT NOT NULL, " +
                GoalTable.COL_SMS_ENABLED + " INTEGER NOT NULL)";
        db.execSQL(sqlGoal);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Handle adding Goal table if upgrading from older version
        if (oldVersion < 2) {
            String sqlGoal = "CREATE TABLE IF NOT EXISTS " + GoalTable.TABLE + " (" +
                    GoalTable.COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    GoalTable.COL_GOAL_WEIGHT + " TEXT NOT NULL, " +
                    GoalTable.COL_SMS_ENABLED + " INTEGER NOT NULL)";
            db.execSQL(sqlGoal);
        }
    }

    // =================== USER METHODS ===================
    public boolean createUser(String username, String password) {
        if (userExists(username)) return false;

        ContentValues values = new ContentValues();
        values.put(UserTable.COL_USERNAME, username);
        values.put(UserTable.COL_PASSWORD, password);

        SQLiteDatabase db = getWritableDatabase();
        long result = db.insert(UserTable.TABLE, null, values);
        return result != -1;
    }

    public boolean validateLogin(String username, String password) {
        SQLiteDatabase db = getReadableDatabase();

        Cursor cursor = db.query(UserTable.TABLE,
                new String[]{UserTable.COL_PASSWORD},
                UserTable.COL_USERNAME + " = ?",
                new String[]{username},
                null, null, null);

        if (!cursor.moveToFirst()) {
            cursor.close();
            return false;
        }

        String storedPassword = cursor.getString(0);
        cursor.close();
        return password.equals(storedPassword);
    }

    private boolean userExists(String username) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query(UserTable.TABLE,
                new String[]{UserTable.COL_ID},
                UserTable.COL_USERNAME + " = ?",
                new String[]{username},
                null, null, null);

        boolean exists = cursor.moveToFirst();
        cursor.close();
        return exists;
    }

    // =================== WEIGHT METHODS ===================
    public boolean addWeightEntry(String date, String weight) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(WeightTable.COL_DATE, date);
        values.put(WeightTable.COL_WEIGHT, weight);

        long result = db.insert(WeightTable.TABLE, null, values);
        return result != -1;
    }

    public boolean updateWeightEntry(String oldDate, String newDate, String newWeight) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(WeightTable.COL_DATE, newDate);
        values.put(WeightTable.COL_WEIGHT, newWeight);

        int rowsAffected = db.update(WeightTable.TABLE,
                values,
                WeightTable.COL_DATE + " = ?",
                new String[]{oldDate});
        return rowsAffected > 0;
    }

    public boolean deleteWeightEntry(String date) {
        SQLiteDatabase db = getWritableDatabase();
        int rowsDeleted = db.delete(WeightTable.TABLE,
                WeightTable.COL_DATE + " = ?",
                new String[]{date});
        return rowsDeleted > 0;
    }

    public List<DataItem> getAllWeightEntries() {
        List<DataItem> list = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();

        Cursor cursor = db.query(
                WeightTable.TABLE,
                new String[]{WeightTable.COL_DATE, WeightTable.COL_WEIGHT},
                null, null, null, null,
                WeightTable.COL_DATE + " ASC"
        );

        while (cursor.moveToNext()) {
            String date = cursor.getString(cursor.getColumnIndexOrThrow(WeightTable.COL_DATE));
            String weight = cursor.getString(cursor.getColumnIndexOrThrow(WeightTable.COL_WEIGHT));
            list.add(new DataItem(date, weight));
        }
        cursor.close();
        return list;
    }

    public static class DataItem {
        public String date;
        public String value;

        public DataItem(String date, String value) {
            this.date = date;
            this.value = value;
        }
    }

    // =================== GOAL METHODS ===================
    public void saveGoal(String goalWeight, boolean smsEnabled) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(GoalTable.COL_GOAL_WEIGHT, goalWeight);
        values.put(GoalTable.COL_SMS_ENABLED, smsEnabled ? 1 : 0);

        // Check if a goal row exists
        Cursor cursor = db.query(GoalTable.TABLE,
                new String[]{GoalTable.COL_ID},
                null, null, null, null, null);

        if (cursor.moveToFirst()) {
            // Update existing goal
            db.update(GoalTable.TABLE, values,
                    GoalTable.COL_ID + " = ?",
                    new String[]{String.valueOf(cursor.getInt(0))});
        } else {
            // Insert new goal
            db.insert(GoalTable.TABLE, null, values);
        }
        cursor.close();
    }

    /**
     * Returns the saved goal as a Cursor. Always safe because table exists.
     */
    public Cursor getGoal() {
        SQLiteDatabase db = getReadableDatabase();
        return db.query(GoalTable.TABLE,
                null, null, null, null, null, null);
    }
}
