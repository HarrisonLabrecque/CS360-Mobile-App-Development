package com.harrison.weighttracker;

import android.content.Intent;        // Used to navigate between activities
import android.os.Bundle;             // Used for activity lifecycle state
import android.widget.Button;         // Button UI component
import android.widget.EditText;       // Text input UI component
import android.widget.Toast;          // Small popup messages for feedback

import androidx.appcompat.app.AppCompatActivity; // Base class for activities

/**
 * LoginActivity handles user authentication.
 * Users can log in with existing credentials or create a new account.
 */
public class LoginActivity extends AppCompatActivity {

    // Reference to the database helper class
    private UserDataBase userDataBase;

    // UI components
    private EditText etUsername;       // Input field for username
    private EditText etPassword;       // Input field for password
    private Button btnLogin;           // Button to log in
    private Button btnCreateAccount;   // Button to create a new account

    /**
     * Called when the activity is first created.
     * Sets up the UI and initializes database and listeners.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Inflate the layout XML for this screen
        setContentView(R.layout.login_activity);

        // Initialize the database using this activity as context
        userDataBase = new UserDataBase(this);

        // Initialize UI element references
        initViews();

        // Attach button click listeners
        setupListeners();
    }

    /**
     * Finds and links UI components from the XML layout.
     */
    private void initViews() {
        etUsername = findViewById(R.id.etUsername);           // Username input
        etPassword = findViewById(R.id.etPassword);           // Password input
        btnLogin = findViewById(R.id.btnLogin);               // Login button
        btnCreateAccount = findViewById(R.id.btnCreateAccount); // Create Account button
    }

    /**
     * Sets click listeners for Login and Create Account buttons.
     */
    private void setupListeners() {
        // Attempt login when Login button is clicked
        btnLogin.setOnClickListener(v -> loginUser());

        // Attempt account creation when Create Account button is clicked
        btnCreateAccount.setOnClickListener(v -> createAccount());
    }

    /**
     * Handles the login process.
     * Validates user input and checks credentials against the database.
     */
    private void loginUser() {
        // Retrieve user-entered username and password
        String username = etUsername.getText().toString().trim();
        String password = etPassword.getText().toString().trim();

        // Prevent login if fields are empty
        if (username.isEmpty() || password.isEmpty()) {
            showToast(R.string.login_error_empty);
            return;
        }

        // Validate credentials using the database instance
        boolean success = userDataBase.validateLogin(username, password);

        if (success) {
            // Inform user of successful login
            Toast.makeText(this, "Login successful", Toast.LENGTH_SHORT).show();

            // Navigate to the Weight History screen
            Intent intent = new Intent(this, WeightHistoryActivity.class);
            startActivity(intent);

            // Prevent returning to login screen with back button
            finish();
        } else {
            // Inform user of failed login attempt
            Toast.makeText(this, "Invalid username or password", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Handles account creation.
     * Creates a new user if the username does not already exist.
     */
    private void createAccount() {
        // Retrieve user-entered username and password
        String username = etUsername.getText().toString().trim();
        String password = etPassword.getText().toString().trim();

        // Prevent account creation if fields are empty
        if (username.isEmpty() || password.isEmpty()) {
            showToast(R.string.login_error_empty);
            return;
        }

        // Attempt to create a new user in the database
        boolean created = userDataBase.createUser(username, password);

        if (created) {
            // Account successfully created
            Toast.makeText(this, "Account created", Toast.LENGTH_SHORT).show();
        } else {
            // Username already exists
            Toast.makeText(this, "Username already exists", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Displays a short Toast message using a string resource.
     *
     * @param messageResId Resource ID of the message to display
     */
    private void showToast(int messageResId) {
        Toast.makeText(this, getString(messageResId), Toast.LENGTH_SHORT).show();
    }
}
