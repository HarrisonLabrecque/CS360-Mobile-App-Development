package com.harrison.weighttracker;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AddWeightActivity extends AppCompatActivity {

    private EditText etDate, etWeight;
    private Button btnSaveWeight;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_weight_activity);

        // Initialize views
        etDate = findViewById(R.id.etDate);
        etWeight = findViewById(R.id.etWeight);
        btnSaveWeight = findViewById(R.id.btnSaveWeight);

        // Button click listener
        btnSaveWeight.setOnClickListener(v -> saveWeight());
    }

    private void saveWeight() {
        String date = etDate.getText().toString().trim();
        String weight = etWeight.getText().toString().trim();

        // Validate input
        if (date.isEmpty() || weight.isEmpty()) {
            Toast.makeText(this, "Please enter date and weight", Toast.LENGTH_SHORT).show();
            return;
        }

        // Send data back to WeightHistoryActivity
        Intent resultIntent = new Intent();
        resultIntent.putExtra("date", date);
        resultIntent.putExtra("weight", weight);
        setResult(RESULT_OK, resultIntent);

        // Close this activity
        finish();
    }
}

