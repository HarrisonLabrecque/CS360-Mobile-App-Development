package com.harrison.weighttracker;

import android.Manifest;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

/**
 * Activity for entering goal weight and SMS preferences
 */
public class SetGoalActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 101;

    private EditText etGoalWeight;
    private SwitchCompat switchSms;   // Use SwitchCompat for AppCompat
    private TextView tvSmsStatus;

    private UserDataBase dataBase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.set_goal_activity);

        dataBase = new UserDataBase(this);

        etGoalWeight = findViewById(R.id.etGoalWeight);
        switchSms = findViewById(R.id.switchSms);
        tvSmsStatus = findViewById(R.id.tvSmsStatus);
        Button btnSaveGoal = findViewById(R.id.btnSaveGoal);

        updateSmsStatus();
        loadSavedGoal();

        // SMS switch listener
        switchSms.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) checkSmsPermission();
        });

        // Save goal button
        btnSaveGoal.setOnClickListener(v -> {
            String goalText = etGoalWeight.getText().toString().trim();
            if (goalText.isEmpty()) {
                Toast.makeText(this,
                        getString(R.string.goal_weight_hint),
                        Toast.LENGTH_SHORT).show();
                return;
            }

            boolean smsEnabled = switchSms.isChecked();

            // Save goal to database
            dataBase.saveGoal(goalText, smsEnabled);

            Toast.makeText(this,
                    getString(R.string.goal_saved),
                    Toast.LENGTH_SHORT).show();

            finish(); // Return to previous screen
        });
    }

    /** Load previously saved goal from database */
    private void loadSavedGoal() {
        Cursor cursor = dataBase.getGoal();
        if (cursor.moveToFirst()) {
            String goalWeight = cursor.getString(
                    cursor.getColumnIndexOrThrow("goal_weight"));
            int smsEnabled = cursor.getInt(
                    cursor.getColumnIndexOrThrow("sms_enabled"));

            etGoalWeight.setText(goalWeight);
            switchSms.setChecked(smsEnabled == 1);
        }
        cursor.close();
    }

    /** Check SMS permission, request if not granted */
    private void checkSmsPermission() {
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_CODE);
        } else {
            tvSmsStatus.setText(R.string.sms_permission_granted);
        }
    }

    /** Update SMS status text */
    private void updateSmsStatus() {
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            tvSmsStatus.setText(R.string.sms_permission_granted);
        } else {
            tvSmsStatus.setText(R.string.sms_permission_not_granted);
        }
    }

    /** Handle runtime permission result */
    @Override
    public void onRequestPermissionsResult(
            int requestCode,
            @NonNull String[] permissions,
            @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 &&
                    grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                tvSmsStatus.setText(R.string.sms_permission_granted);
            } else {
                switchSms.setChecked(false);
                tvSmsStatus.setText(R.string.sms_permission_not_granted);
                Toast.makeText(this,
                        getString(R.string.sms_permission_not_granted),
                        Toast.LENGTH_SHORT).show();
            }
        }
    }
}
